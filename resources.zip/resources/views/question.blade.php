@extends('layout.seclanding')
@section('content')
<article id="quest">
</article>
@endsection
