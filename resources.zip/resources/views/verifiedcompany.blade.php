@extends('layout.seclanding')
@section('content')
<div id="emailcompany">

</div>
@endsection
