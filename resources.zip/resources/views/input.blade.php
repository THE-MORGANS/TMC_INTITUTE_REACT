@extends('layout.seclanding')
@section('content')
<section id="input">
</section>
@endsection
