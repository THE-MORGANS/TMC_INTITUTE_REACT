@extends('newdesign.layout.adminside')
@section('content')
<div id="admindash">
</div>
@endsection
