@extends('newdesign.layout.newindex')
@section('content')
    <div id="aboutrent">

    </div>
@endsection 
