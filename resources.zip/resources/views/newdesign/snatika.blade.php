
@extends('newdesign.layout.newindex')
@section('content')
<div id="snatika">

</div>
@endsection
