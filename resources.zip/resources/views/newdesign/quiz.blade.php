@extends('newdesign.layout.quiztake')
@section('content')
<div id="quiz"></div>
@endsection
