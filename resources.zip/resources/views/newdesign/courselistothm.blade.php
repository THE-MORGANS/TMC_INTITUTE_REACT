@extends('newdesign.layout.newindex')
@section('content')
<div id="courselistothm">

</div>
@endsection  
