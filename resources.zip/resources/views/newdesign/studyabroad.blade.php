@extends('newdesign.layout.newindex')
@section('content')
    <div id="study">

    </div>
@endsection 
