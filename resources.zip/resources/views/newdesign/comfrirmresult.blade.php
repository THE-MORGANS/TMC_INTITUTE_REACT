@extends('newdesign.layout.comfirmcert')
@section('content')
<div id="result"></div>
@endsection
