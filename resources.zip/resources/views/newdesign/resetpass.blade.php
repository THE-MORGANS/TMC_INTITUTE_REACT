@extends('newdesign.layout.changepass')
@section('content')
<div id="resetpas">
</div>
@endsection
