@extends('newdesign.layout.newindex')
@section('content')
<div id="cart">
    
</div>
@endsection
