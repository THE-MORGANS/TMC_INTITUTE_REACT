@extends('newdesign.layout.newindex')
@section('content')
<div id="courseinfo"></div> 
@endsection