@extends('newdesign.layout.newindex')
@section('content')
<div id='terms'></div> 
@endsection
 
