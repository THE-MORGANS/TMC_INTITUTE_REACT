@extends('newdesign.layout.first')
@section('content')
<div id="othm"></div>
@endsection
