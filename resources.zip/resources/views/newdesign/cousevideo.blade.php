@extends('newdesign.layout.video')
@section('content')
<section id="watch">
</section>
@endsection
