@extends('newdesign.layout.adminother')
@section('content')
<div id="rate">
</div>
@endsection
