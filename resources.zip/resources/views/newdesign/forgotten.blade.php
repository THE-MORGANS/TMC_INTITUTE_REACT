@extends('layout.seclanding')
@section('content')

<div id="forgot">
    
</div>
@endsection
  