@extends('newdesign.layout.first')
@section('content')
<div id="newdash"> 

</div>
@endsection 
