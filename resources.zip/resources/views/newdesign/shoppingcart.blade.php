{{-- @extends('newdesign.layout.first') --}}
@extends('newdesign.layout.newindex')

@section('content')
<div id="shoppingcart"></div>

@endsection  
