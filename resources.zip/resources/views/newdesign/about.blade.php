@extends('newdesign.layout.abouttmc')
@section('content')
<div id='aboutrent'>
</div>
@endsection
