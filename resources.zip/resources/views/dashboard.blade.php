@extends('layout.landing')
@section('content')
    <div id="dash">

    </div>
@endsection


