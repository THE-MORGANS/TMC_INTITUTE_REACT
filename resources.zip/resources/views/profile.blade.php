@extends('newdesign.layout.profilelanding')
@section('content')
<div id="profile">

</div>
@endsection  
