@extends('layout.seclanding')
@section('content')
<div id='login'>
 
</div>
@endsection
