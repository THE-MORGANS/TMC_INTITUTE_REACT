@extends('layout.landing')
@section('content')
<div id="aboutcorse">

</div>
@endsection
