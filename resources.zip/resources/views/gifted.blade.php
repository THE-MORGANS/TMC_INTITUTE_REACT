@extends('layout.seclanding')
@section('content')
<div id="gifted">

</div>
@endsection
