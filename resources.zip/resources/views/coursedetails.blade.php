@extends('layout.landing')
@section('content')
<div id='course'>

</div>
@endsection
