@extends('layout.seclanding')
@section('content')
<article id='reside'>
</article>
@endsection
