@extends('layout.seclanding')
@section('content')
<div id="active">
</div>
@endsection 
 