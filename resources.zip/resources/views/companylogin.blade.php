@extends('layout.seclanding')
@section('content')
<div id="companylogin">
</div>
@endsection