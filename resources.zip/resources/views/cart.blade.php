@extends('layout.seclanding')
{{-- @extends('newdesign.layout.profilelanding') --}}

@section('content')
<div id="">

</div>
@endsection
