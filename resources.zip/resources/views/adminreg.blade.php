@extends('layout.seclanding')
@section('content')
<section id="adminreg">
</section>
@endsection 
