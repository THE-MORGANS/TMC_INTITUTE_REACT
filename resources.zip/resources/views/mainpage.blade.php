@extends('layout.seclanding')
@section('content')
<div id="page">

</div>
@endsection