@extends('layout.seclanding')
@section('content')
<article id="policy"></article>
@endsection
