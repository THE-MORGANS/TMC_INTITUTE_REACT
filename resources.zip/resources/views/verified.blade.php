@extends('layout.seclanding')
@section('content')
<div id="email"></div>
@endsection
