@extends('layout.landing')
@section('content')
    <div id="example">

    </div>
@endsection


