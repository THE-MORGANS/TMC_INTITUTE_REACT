@extends('layout.seclanding')
@section('content')
<div id="cont">

</div>
@endsection
