// Study.js
import React from 'react';

function HowtoApply() {
  return <h2>HowtoApply</h2>;
}

export default HowtoApply;
