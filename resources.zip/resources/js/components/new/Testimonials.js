// Study.js
import React from 'react';

function Testimonials() {
  return <h2>Testimonials</h2>;
}

export default Testimonials;
