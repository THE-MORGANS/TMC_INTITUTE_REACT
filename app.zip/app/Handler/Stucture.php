<?php

array(


      [
        "questionText"=>"Which of the following is not an example of a suspicious transaction?",
        "answerOptions"=> array(
            [ "answerText"=> 'Invoice payment discrepancies', "isCorrect"=> false ],
            [ "answerText"=> 'Large dividend payments', "isCorrect"=> true ],
            [ "answerText"=> 'Suspected price fixing', "isCorrect"=> false ],
            [ "answerText"=> 'Unusual instructions from a client', "isCorrect"=> false ],
        ),

          ],


);






?>
